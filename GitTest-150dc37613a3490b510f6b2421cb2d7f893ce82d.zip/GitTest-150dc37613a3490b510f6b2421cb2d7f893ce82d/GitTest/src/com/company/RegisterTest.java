package com.company;

import static org.junit.jupiter.api.Assertions.*;

class RegisterTest {

    @org.junit.jupiter.api.Test
    void reg()
    {
        
    }

    @org.junit.jupiter.api.Test
    void testReg()
    {

    }

    @org.junit.jupiter.api.Test
    void del()
    {

    }
}